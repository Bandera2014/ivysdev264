package com.example.lab10

class Post {

    var name:String?=null
    var desc:String?=null

    constructor(name:String,desc:String){
        this.name=name
        this.desc=desc
    }



    override fun toString(): String {
        return "Post(name=$name, desc=$desc)"
    }


}